function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    if (username && password) {
        document.getElementById('loginPage').classList.add('hidden');
        document.getElementById('dashboardPage').classList.remove('hidden');
        document.getElementById('displayUsername').textContent = username;
    } else {
        alert('Sila masukkan username dan password.');
    }
}

let equity = 0;

function addEquity(amount) {
    equity += amount;
    document.getElementById('equityAmount').textContent = 'RM' + equity;
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('tradeHistory').innerHTML += `
        <tr>
            <td>${today}</td>
            <td>-</td>
            <td>Deposit</td>
            <td>RM${amount}</td>
        </tr>
    `;
}

function requestWithdrawal() {
    alert('Permintaan withdrawal telah dihantar. Sila tunggu pihak admin memproses.');
}